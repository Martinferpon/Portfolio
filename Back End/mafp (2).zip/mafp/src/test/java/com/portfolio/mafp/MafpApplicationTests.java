package com.portfolio.mafp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MafpApplicationTests {

	@Test
	void contextLoads() {
	}

}
