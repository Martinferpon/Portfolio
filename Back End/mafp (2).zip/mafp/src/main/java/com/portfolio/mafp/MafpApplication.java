package com.portfolio.mafp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MafpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MafpApplication.class, args);
	}

}
